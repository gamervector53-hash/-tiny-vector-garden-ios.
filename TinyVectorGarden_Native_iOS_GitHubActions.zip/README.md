# Tiny Vector Garden — Native iOS

This is a real native SwiftUI iPhone game. It does **not** use a web page or WKWebView.

## What it does
- Native SwiftUI UI
- 9 garden plots
- Plant seeds
- ~5.5 second growth cycle
- Harvest flowers for coins
- Buy seeds
- Unlock plots
- XP + levels
- Local save using UserDefaults

## Build an unsigned IPA with GitHub Actions
The included workflow runs on a macOS runner, builds for a real iPhone (`iphoneos`) with code signing disabled, then packages the `.app` into a standard `Payload/...app` IPA.

1. Put these files in a GitHub repository.
2. Open **Actions**.
3. Run **Build unsigned iOS IPA** (or push to `main`).
4. Open the completed run.
5. Download the `TinyVectorGarden-unsigned-ipa` artifact.
6. Extract the artifact ZIP to get `TinyVectorGarden-unsigned.ipa`.
7. Resign/install it with your own sideloading setup.

Bundle identifier: `com.vector.tinyvectorgarden`
Minimum iOS: 17.0
