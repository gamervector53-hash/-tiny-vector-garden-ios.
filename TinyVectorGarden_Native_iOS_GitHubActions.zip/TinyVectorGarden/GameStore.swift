import Foundation
import SwiftUI

enum PlotState: String, Codable {
    case locked
    case empty
    case growing
    case ready
}

struct GardenPlot: Identifiable, Codable {
    let id: Int
    var state: PlotState
    var plantedAt: Date?
}

private struct SavedGame: Codable {
    var coins: Int
    var seeds: Int
    var harvests: Int
    var level: Int
    var xp: Int
    var unlocked: Int
    var plots: [GardenPlot]
}

@MainActor
final class GameStore: ObservableObject {
    @Published var coins = 12
    @Published var seeds = 6
    @Published var harvests = 0
    @Published var level = 1
    @Published var xp = 0
    @Published var unlocked = 6
    @Published var plots: [GardenPlot] = []

    let growSeconds: TimeInterval = 5.5
    private let saveKey = "tiny-vector-garden-save-v1"

    init() {
        if !load() {
            reset()
        }
        refreshGrowth()
    }

    var xpNeeded: Int { 4 + level }
    var unlockCost: Int { 10 + max(0, unlocked - 6) * 5 }
    var allUnlocked: Bool { unlocked >= 9 }

    func reset() {
        coins = 12
        seeds = 6
        harvests = 0
        level = 1
        xp = 0
        unlocked = 6
        plots = (0..<9).map {
            GardenPlot(id: $0, state: $0 < unlocked ? .empty : .locked, plantedAt: nil)
        }
        save()
    }

    @discardableResult
    func refreshGrowth() -> Bool {
        let now = Date()
        var changed = false

        for index in plots.indices where plots[index].state == .growing {
            if let plantedAt = plots[index].plantedAt,
               now.timeIntervalSince(plantedAt) >= growSeconds {
                plots[index].state = .ready
                changed = true
            }
        }

        if changed { save() }
        return changed
    }

    func secondsLeft(for plot: GardenPlot) -> Int {
        guard plot.state == .growing, let plantedAt = plot.plantedAt else { return 0 }
        let remaining = growSeconds - Date().timeIntervalSince(plantedAt)
        return max(0, Int(ceil(remaining)))
    }

    func progress(for plot: GardenPlot) -> Double {
        guard plot.state == .growing, let plantedAt = plot.plantedAt else {
            return plot.state == .ready ? 1 : 0
        }
        return min(1, max(0, Date().timeIntervalSince(plantedAt) / growSeconds))
    }

    func tapPlot(_ id: Int) -> String {
        refreshGrowth()
        guard let index = plots.firstIndex(where: { $0.id == id }) else { return "" }

        switch plots[index].state {
        case .locked:
            return "That plot is locked. Unlock it below. 🔒"

        case .empty:
            guard seeds > 0 else {
                return "Out of seeds 🌰 Buy a few more."
            }
            seeds -= 1
            plots[index].state = .growing
            plots[index].plantedAt = Date()
            save()
            return "Planted! Your flower is growing 🌱"

        case .growing:
            return "Still growing — about \(secondsLeft(for: plots[index]))s left."

        case .ready:
            let reward = 3 + max(0, (level - 1) / 3)
            coins += reward
            harvests += 1
            gainXP(1)
            plots[index].state = .empty
            plots[index].plantedAt = nil
            save()
            return "Harvested! +\(reward) coins 🌻"
        }
    }

    func buySeeds() -> String {
        guard coins >= 4 else { return "You need 4 coins for the seed pack." }
        coins -= 4
        seeds += 3
        save()
        return "Bought 3 seeds 🌰"
    }

    func unlockNextPlot() -> String {
        guard !allUnlocked else { return "Every plot is already unlocked." }
        let cost = unlockCost
        guard coins >= cost else { return "You need \(cost) coins to unlock another plot." }

        coins -= cost
        if let index = plots.firstIndex(where: { $0.state == .locked }) {
            plots[index].state = .empty
            unlocked += 1
        }
        save()
        return "New garden plot unlocked! 🔓"
    }

    private func gainXP(_ amount: Int) {
        xp += amount
        while xp >= xpNeeded {
            let needed = xpNeeded
            xp -= needed
            level += 1
            coins += 5
        }
    }

    private func save() {
        let snapshot = SavedGame(
            coins: coins,
            seeds: seeds,
            harvests: harvests,
            level: level,
            xp: xp,
            unlocked: unlocked,
            plots: plots
        )
        if let data = try? JSONEncoder().encode(snapshot) {
            UserDefaults.standard.set(data, forKey: saveKey)
        }
    }

    private func load() -> Bool {
        guard
            let data = UserDefaults.standard.data(forKey: saveKey),
            let snapshot = try? JSONDecoder().decode(SavedGame.self, from: data)
        else { return false }

        coins = snapshot.coins
        seeds = snapshot.seeds
        harvests = snapshot.harvests
        level = snapshot.level
        xp = snapshot.xp
        unlocked = snapshot.unlocked
        plots = snapshot.plots
        return plots.count == 9
    }
}
