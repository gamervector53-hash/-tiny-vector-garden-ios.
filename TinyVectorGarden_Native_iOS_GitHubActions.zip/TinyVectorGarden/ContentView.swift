import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var game: GameStore
    @State private var message = "Tap an empty soil plot to plant a seed."
    private let tick = Timer.publish(every: 0.25, on: .main, in: .common).autoconnect()

    private let columns = Array(repeating: GridItem(.flexible(), spacing: 10), count: 3)

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.88, green: 0.96, blue: 0.82),
                    Color(red: 0.74, green: 0.89, blue: 0.65)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 12) {
                    header
                    stats
                    xpCard
                    garden
                    messageCard
                    actionButtons
                }
                .padding(.horizontal, 14)
                .padding(.top, 10)
                .padding(.bottom, 24)
            }
        }
        .onReceive(tick) { _ in
            _ = game.refreshGrowth()
        }
    }

    private var header: some View {
        HStack(alignment: .bottom, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text("🌱 Tiny Vector Garden")
                    .font(.system(size: 27, weight: .heavy, design: .rounded))
                    .minimumScaleFactor(0.7)

                Text("Grow tiny. Profit irresponsibly.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            VStack(spacing: 1) {
                Text("Level")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                Text("\(game.level)")
                    .font(.title3.bold())
            }
            .padding(.horizontal, 13)
            .padding(.vertical, 8)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
        }
    }

    private var stats: some View {
        HStack(spacing: 8) {
            StatCard(value: "🪙 \(game.coins)", label: "COINS")
            StatCard(value: "🌰 \(game.seeds)", label: "SEEDS")
            StatCard(value: "🌻 \(game.harvests)", label: "HARVESTS")
        }
    }

    private var xpCard: some View {
        VStack(spacing: 7) {
            HStack {
                Text("Garden XP")
                Spacer()
                Text("\(game.xp) / \(game.xpNeeded)")
            }
            .font(.caption)
            .foregroundStyle(.secondary)

            ProgressView(value: Double(game.xp), total: Double(game.xpNeeded))
                .tint(.green)
        }
        .padding(12)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
    }

    private var garden: some View {
        LazyVGrid(columns: columns, spacing: 10) {
            ForEach(game.plots) { plot in
                PlotButton(plot: plot)
                    .environmentObject(game)
                    .onTapGesture {
                        message = game.tapPlot(plot.id)
                    }
            }
        }
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 24)
                .fill(Color(red: 0.65, green: 0.82, blue: 0.53))
                .shadow(color: .black.opacity(0.12), radius: 10, y: 5)
        )
    }

    private var messageCard: some View {
        Text(message)
            .font(.subheadline.weight(.semibold))
            .frame(maxWidth: .infinity, minHeight: 48, alignment: .leading)
            .padding(.horizontal, 13)
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
    }

    private var actionButtons: some View {
        HStack(spacing: 9) {
            Button {
                message = game.buySeeds()
            } label: {
                VStack(spacing: 2) {
                    Text("🌰 3 seeds")
                    Text("4 coins").font(.caption)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
            }
            .buttonStyle(.borderedProminent)
            .tint(.green)

            Button {
                message = game.unlockNextPlot()
            } label: {
                VStack(spacing: 2) {
                    Text(game.allUnlocked ? "🔓 All plots" : "🔓 Unlock plot")
                    Text(game.allUnlocked ? "MAX" : "\(game.unlockCost) coins")
                        .font(.caption)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
            }
            .buttonStyle(.borderedProminent)
            .tint(.yellow)
            .foregroundStyle(.black)
            .disabled(game.allUnlocked)
        }
    }
}

private struct StatCard: View {
    let value: String
    let label: String

    var body: some View {
        VStack(spacing: 3) {
            Text(value)
                .font(.system(size: 18, weight: .heavy, design: .rounded))
                .minimumScaleFactor(0.6)
                .lineLimit(1)
            Text(label)
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}

private struct PlotButton: View {
    @EnvironmentObject private var game: GameStore
    let plot: GardenPlot

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 20)
                .fill(background)

            VStack(spacing: 5) {
                Text(emoji)
                    .font(.system(size: 38))

                Text(label)
                    .font(.caption2.bold())
                    .foregroundStyle(.white)

                if plot.state == .growing {
                    ProgressView(value: game.progress(for: plot))
                        .tint(.yellow)
                        .padding(.horizontal, 15)
                }
            }
            .padding(8)
        }
        .aspectRatio(1, contentMode: .fit)
        .overlay {
            if plot.state == .ready {
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.yellow, lineWidth: 4)
                    .shadow(color: .yellow.opacity(0.5), radius: 8)
            }
        }
        .contentShape(RoundedRectangle(cornerRadius: 20))
    }

    private var background: Color {
        switch plot.state {
        case .locked:
            return Color(red: 0.45, green: 0.53, blue: 0.48)
        default:
            return Color(red: 0.57, green: 0.36, blue: 0.23)
        }
    }

    private var emoji: String {
        switch plot.state {
        case .locked: return "🔒"
        case .empty: return "🟫"
        case .growing:
            return game.progress(for: plot) > 0.66 ? "🌿" : "🌱"
        case .ready: return "🌻"
        }
    }

    private var label: String {
        switch plot.state {
        case .locked: return "LOCKED"
        case .empty: return "PLANT"
        case .growing: return "\(game.secondsLeft(for: plot))s"
        case .ready: return "HARVEST!"
        }
    }
}
